function ouf = cc(x)

% correction function
% cc = Psi(z_i/(\|z\|_\infty)
% Psi(t) = sgn(t)(1+\epsilon^{\tau})|t|^{\tau}/(|t|^{\tau} + \epsilon^{\tau})
% We set \tau = 2 and epsilon^{\tau} = 0.001;

% x: initial estimae value in corrected TVL1

espon = 0.001;
t = max(abs(x(:)));
x=x/t;
ouf = sign(x).*(ones(size(x))*espon+ones(size(x))).*abs(x).*abs(x)./(abs(x).*abs(x)+ones(size(x))*espon);

end
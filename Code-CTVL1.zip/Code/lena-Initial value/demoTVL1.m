function out = demoTVL1
%
% Demo TV/L1 solve
%

clear; close all; 
path(path,genpath(pwd));

%% generate data -- see nested function below
[I,H,Bn,mu] = genData;

%% Run FTVd_v4.0
tic;
out = ADMMTVL1(H,Bn,mu);
t = toc;

% PSNR
[ximage,yimage]=size(I);
y = 10*log10(ximage*yimage/sum(sum((I-out.sol).^2)))

%% Plot result
figure(1);
subplot(121); imshow(Bn,[]);
title(sprintf('Corruption: %4.0f%%',level*100),'fontsize',13); 
subplot(122); imshow(out.sol,[]);
title(sprintf('SNR %4.2fdB, CPU %4.2fs, It %d, PSNR %4.2fdB',snr(out.sol),t,out.itr, y),'fontsize',13); 

fprintf('Corruption %2.0d%%, SNR(Recovered) %4.2fdB,',level*100,snr(out.sol));
fprintf(' CPU %4.2fs, Iteration %d\n\n',t,out.itr);

%% nested function 
function [I,H,Bn,mu] = genData
%I = double(imread('cameraman.tif'))/255;
I = double(imread('standard_lena.bmp'))/255;
%I = double(imread('lena256.png'))/255;
%I = double(imread('house.png'))/255;

H = fspecial('average',9);

level = .50;
Bn = imfilter(I,H,'circular','conv');
Bn = imnoise(Bn,'salt & pepper',level);
%Bn = addnoise(Bn, level, 'rd');
snr(Bn,I);

% suggested mu (not too bad)
switch level
    case 0.10; mu = 20;
    case 0.20; mu = 50;
    case 0.25; mu = 60;
    case 0.30; mu = 40;
    case 0.40; mu = 35;
    case 0.50; mu = 10;
    case 0.60; mu = 4;
    case 0.70; mu = 5;
    case 0.90; mu = 3;
    otherwise
        mu = input('Input mu:');
end

end

end

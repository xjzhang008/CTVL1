Adaptive correction procedure for TVL1 image deblurring under impulse noise, Inverse Problems, 32(8):085004,2016.


The algorithm proceeds as follows:

First step: generate an initial eatimator W by TVL1 (used the code of Junfeng Yang, Yin Zhang, and Wotao Yin for TVL1) (the lena-Initial value folder)

Second step: Sove the corrected model with the initial estimator W (Lena-Correction Procedure folder)

If necessary, the second step will repeat many times. 
W will be updated by the current solution.

 @copyright, Minru Bai, XIongjun Zhang, Qianqian Shao.